#include "GameBoard.h"
#include "Snake.h"
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <windows.h>
#include <conio.h>

// prototype end of game function
void endOfGame(int score, HANDLE& hConsole);

int main() {
	// define the console handle and hide the print cursor location marker
	HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_CURSOR_INFO cursorInfo;
	GetConsoleCursorInfo(hConsole, &cursorInfo);
	cursorInfo.bVisible = FALSE;   // hide cursor
	SetConsoleCursorInfo(hConsole, &cursorInfo);

	// seed random time and update game states
	srand(static_cast<unsigned int>(time(NULL)));
	// collect the time stamp from the start of the game
	int timeStamp = clock();

	// define game states and their default values
	bool gameInProgress = true;
	int score = 0;

	// define game objects
	Snake snake;
	GameBoard board;

	// execute game loop while the game is in progress
	while (gameInProgress) {

		// gain a key input and call changeDirection
		if (_kbhit()) {
			int key = _getch();
			if (key == 'w') {
				snake.changeDirection(up);
			}
			else if (key == 'a') {
				snake.changeDirection(left);
			}
			else if (key == 's') {
				snake.changeDirection(down);
			}
			else if (key == 'd') {
				snake.changeDirection(right);
			}
		}

		// re-calculate the time passed by comparing timestamp with current time
		int timeElapsed = (clock() - timeStamp) / (CLOCKS_PER_SEC / 1000);
		
		// if the new frame is ready to be generated
		if (timeElapsed > 200) {
			// set the print location to be the top left corner to overwrite old board
			SetConsoleCursorPosition(hConsole, { 0, 0 });

			// preform a move 
			gameInProgress = snake.move();

			// if it is currently in the apples place eat and reset the apple
			if (snake.getHead().row == board.getApple().row && snake.getHead().column == board.getApple().column) {
				// eat and reseat apple and increase the score
				snake.eat();
				score++;
				board.placeApple(snake);
			}

			// update the board and reset the timestamp
			board.updateBoard(snake);
			timeStamp = clock();

			// print the board out after updates
			board.printBoard();

		}

	}

	// define the end of the game...
	endOfGame(score, hConsole);
	
	// return to os
	return 0;
}

// print a message with the score and prompting the end of game message
void endOfGame(int score, HANDLE& hConsole) {
	system("cls");
	SetConsoleTextAttribute(hConsole, 2);
	std::cout << "END OF GAME" << std::endl;
	std::cout << "Score: " << score << std::endl;
	SetConsoleTextAttribute(hConsole, 7);
}