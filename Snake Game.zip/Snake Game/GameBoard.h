#pragma once
#include "Snake.h"

// define the board size
#define BOARD_SIZE 27

class GameBoard {
private:
	char board[BOARD_SIZE][BOARD_SIZE];
	position apple{ 15, 15 };
public:
	GameBoard();
	void printBoard();
	const position getApple() const;
	void updateBoard(const Snake& snake);
	void placeApple(const Snake& snake);
};