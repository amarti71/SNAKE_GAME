#pragma once
#include <deque>

// define the board size
#define BOARD_SIZE 27

struct position {
	int row;
	int column;

	position(int r, int c)
		: row(r), column(c) {}
};

enum direction {
	up,
	down, 
	left, 
	right
};

class Snake {
private: 
	std::deque<position> body;
	direction dir;
	bool grow;
public:
	Snake();
	void eat();
	bool move();
	void changeDirection(direction dir);
	position getHead();
	bool isSnakeHere(position cord) const;
	const std::deque<position>& getSnake() const;
};