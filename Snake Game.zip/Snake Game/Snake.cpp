#include "Snake.h"

// constructor
Snake::Snake(){
	// make the snake start at the top left corner
	for (int i = 0; i < 4; i++) {
		body.push_front({ 0,i });
	}
	// facing right
	dir = right;
	grow = false;
}

// when eat is called, grow states is set to true
void Snake::eat() {
	grow = true;
}

// change the direction of the snake if and only if it inst turning 180 deg 
void Snake::changeDirection(direction dir) {
	bool canTurn = true;
	// make sure the snake is not turning into itself
	if ((this->dir == left && dir == right) || (this->dir == right && dir == left)) canTurn = false;
	else if ((this->dir == up && dir == down) || (this->dir == down && dir == up)) canTurn = false;
	// if it is not, then update the direction
	if (canTurn) this->dir = dir;
}

// return a boolean that says wether or not the snake is at a coordinate
bool Snake::isSnakeHere(position cord) const{
	bool returnValue = false;
	// search the snake to see if the passed position intersects
	for (int i = 0; i < this->body.size(); i++) {
		if (this->body[i].row == cord.row && this->body[i].column == cord.column) returnValue = true;
	}
	return returnValue;
}

// return the coordinate of the head
position Snake::getHead() {
	return this->body[0];
}

// return a copy of the snake
const std::deque<position>& Snake::getSnake() const {
	return this->body;
}

// move the snake
bool Snake::move() {
	bool returnValue = true;

	// create a new head with its applied deltas based on direction
	position newHead = this->getHead();
	if (this->dir == left) newHead.column--;
	else if (this->dir == right) newHead.column++;
	else if (this->dir == up) newHead.row--;
	else if (this->dir == down) newHead.row++;

	// check bounds based on predetermined board size
	if (newHead.row < 0 || newHead.row > BOARD_SIZE - 1 || newHead.column < 0 || newHead.column > BOARD_SIZE - 1) {
		returnValue = false; // if out of the board the move was invalid
	}
	else {
		// handle self collision
		if (this->isSnakeHere(newHead)) {
			returnValue = false; // self collision move is invalid
		}
		else { // move is valid
			// move the snake
			body.push_front(newHead);
			if (!grow) { // remove the back part of the tail if not currently growing
				body.pop_back();
			}
			else grow = false;
		}
	}
	// return move validity
	return returnValue;
}