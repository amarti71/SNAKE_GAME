#include "GameBoard.h"
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <windows.h>

// define output handle
HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);

// create some macros to make code more readable
#define BLANK_SPACE 254
#define HEAD 148
#define BODY 240
#define APPLE 162

#define SNAKE_COLOR 2
#define BOARD_COLOR 4

// construct a game board with the current board size
GameBoard::GameBoard() {
	this->apple = { 15, 15 };
	for (int i = 0; i < BOARD_SIZE; i++) {
		for (int j = 0; j < BOARD_SIZE; j++) {
			board[i][j] = (char)BLANK_SPACE;
		}
	}
}

// print the board out with the correct colors for each character type
void GameBoard::printBoard() {
	for (int i = 0; i < BOARD_SIZE; i++) {
		for (int j = 0; j < BOARD_SIZE; j++){
			// if it is part of the snake print it using the snake color
			if (board[i][j] == (char) HEAD || board[i][j] == (char) BODY) SetConsoleTextAttribute(hConsole, SNAKE_COLOR);
			// if it is an apple, print it using the red color
			else if (board[i][j] == (char) APPLE) SetConsoleTextAttribute(hConsole, BOARD_COLOR);
			// otherwise fill the empty space with a board color
			else SetConsoleTextAttribute(hConsole, 11);

			// print out the character with space and reset color buffer
			std::cout << board[i][j] << " ";
			SetConsoleTextAttribute(hConsole, 7);
		}
		std::cout << std::endl;
	}
}

// update the game board based on snakes position
void GameBoard::updateBoard(const Snake& snake) {
	// fill all the spots with a blank space
	for (int i = 0; i < BOARD_SIZE; i++) {
		for (int j = 0; j < BOARD_SIZE; j++) {
			board[i][j] = (char)BLANK_SPACE;
		}
	}

	// iterate the snake
	for (int i = 0; i < snake.getSnake().size(); i++) {
		// if it is not the head
		if (i!=0) {
			// update that board tile with the body character
			board[snake.getSnake()[i].row][snake.getSnake()[i].column] = (char) BODY;
		}
		else { // if it is the head
			// update the board tile with the head character
			board[snake.getSnake()[i].row][snake.getSnake()[i].column] = (char) HEAD;
		}
	}
	
	// place the apple where it is supposed to be
	board[apple.row][apple.column] = (char) APPLE;
}

// place the apple in a random spot on the board
void GameBoard::placeApple(const Snake& snake) {
	int r, c;

	//place the apple in a random spot until the chosen spot inst hitting the snake
	do {
		r = rand() % BOARD_SIZE;
		c = rand() % BOARD_SIZE;
	} while (snake.isSnakeHere({ r, c }));

	// set the apples coordinates to the new random spot
	this->apple = { r, c };
	
}

// return a copy of the apple object
const position GameBoard::getApple() const {
	return this->apple;
}